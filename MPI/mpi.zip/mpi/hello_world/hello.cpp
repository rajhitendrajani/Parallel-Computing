#include <mpi.h>
#include <unistd.h>
#include <iostream>

int main(int argc, char*argv[]) {

int size, rank,i;
char hostname[128];
MPI_Init(&argc,&argv);

MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);
i=gethostname(hostname,sizeof hostname);
printf("I am process %d out of %d . I am running on %s\n",rank,size,hostname);

MPI_Finalize();
return 0;
}

