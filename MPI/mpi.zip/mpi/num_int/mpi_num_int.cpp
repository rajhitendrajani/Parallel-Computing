#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
#include <mpi.h>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

  
int main (int argc, char* argv[]) {
  MPI_Init (&argc, &argv);
  if (argc < 6) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }
  std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();

  int functionid = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  float (*f)(float, int);
  int rank;
  int size;
  float sum = 0;
  float sSum = 0;
 
  MPI_Comm_rank (MPI_COMM_WORLD, &rank);
  MPI_Comm_size (MPI_COMM_WORLD, & size);
  MPI_Status status;

  switch(functionid){
  case 1:
    f = f1;
    break;
  case 2:
    f = f2;
    break;
  case 3:
    f = f3;
    break;
  case 4:
    f = f4;
    break;
  }

  for(int i = (rank * n / size); i < ((rank + 1) * n / size) ;  i++)
{
      sSum += f(a + (i + 0.5) * (float(b-a))/n, intensity) ;
  }
MPI_Reduce(&sSum,&sum, 1, MPI_FLOAT,MPI_SUM, 0, MPI_COMM_WORLD);
 
/* if(rank == 0){
    sum = sSum;
    for(int i = 1; i < size; i++){
        MPI_Recv(&sSum, 1, MPI_INTEGER, i, 100, MPI_COMM_WORLD, &status);
        sum += sSum;
    }
  } else{
      MPI_Send(&sSum, 1, MPI_INTEGER, 0, 100, MPI_COMM_WORLD);
  }
*/


  if(rank == 0){
    std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end - start;
    std::cout << sum*(float(b-a)) / n << std::endl;
    std::cerr << elapsed_seconds.count()  << std::endl;
}
MPI_Finalize();
  return 0;
}
