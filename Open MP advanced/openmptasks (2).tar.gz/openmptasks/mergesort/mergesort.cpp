#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <omp.h>
#include <chrono>
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

  void generateMergeSortData (int* arr, size_t n);
  void checkMergeSortResult (int* arr, size_t n);

#ifdef __cplusplus
}
#endif
void merge_sort_p(int* arr, int* tmp, size_t s); 
void merge_sort(int* arr, int* tmp, size_t s); 
void merge(int* arr, int* tmp, size_t s); 
const int SEQ_CUTOFF = 500;

/*sequential merge*/
void merge(int* arr, int* temp, size_t n)
{
        int l, r, k;

        l = 0;
        r = n/2;
        k = 0;

        while(l < n/2 && r < n)
        {
                if(arr[l] < arr[r])
                {
                        temp[k] = arr[l];
                        k++;
                        l++;
                }
                else
                {
                        temp[k] = arr[r];
                        k++;
                        r++;
                }
        }

        while(l < n/2)
        {
                temp[k] = arr[l];
                k++;
                l++;
        }

        while(r < n)
        {
                temp[k] = arr[r];
                k++;
                r++;
        }

        for(int i = 0; i < n; i++)
        {
                arr[i] = temp[i];
        }
}


void merge_sort_p(int* arr, int* temp, size_t n)
{
        if(n < 2)
        {
                return;
        }

        if(n < SEQ_CUTOFF)
        {
                merge_sort(arr, temp, n);
        }
        else
        {
                #pragma omp task //firstprivate (arr, temp, s)
                merge_sort_p(arr, temp, n/2);
                #pragma omp task //firstprivate (arr, temp, s)
                merge_sort_p(arr + n/2, temp + n/2, n - n/2);

                #pragma omp taskwait
                merge(arr, temp, n);     
        }       
}

/*sequential merge-sort*/
void merge_sort(int* arr, int* temp, size_t n)
{
        if(n < 2)
        {
                return;
        }

        merge_sort(arr, temp, n/2);
        merge_sort(arr + n/2, temp + n/2, n - n/2);
        merge(arr, temp, n);
}


int main (int argc, char* argv[]) {

  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 3) { std::cerr<<"usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  
  // get arr data
  int * arr = new int [n];
  int * temp = new int [n];
  int nbthreads = atoi((argv[2]));
  
  generateMergeSortData (arr, n);
  omp_set_num_threads(nbthreads);
  double begin = omp_get_wtime();
  
  #pragma omp parallel
   {
      #pragma omp single
	merge_sort_p(arr, temp, n);
   }
  //insert sorting code here.


  double end = omp_get_wtime(); 
  checkMergeSortResult (arr, n);
  std::cerr << (end - begin) << std::endl;
  delete[] arr;

  return 0;
}
