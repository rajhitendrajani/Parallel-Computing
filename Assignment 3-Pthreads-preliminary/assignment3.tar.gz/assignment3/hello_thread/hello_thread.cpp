#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
int number;
void* f(void* p) {
int val;
val = *(int*)p;
printf ("I am thread %d in %d\n",val,number);
return  NULL;
}
int main (int argc, char* argv[]) {

  if (argc < 2) {
    std::cerr<<"usage: "<<argv[0]<<" <nbthreads>"<<std::endl;
    return -1;
  }
sscanf(argv[1], "%d",&number);
pthread_t  nbthreads[number] ;
for (int i=0; i < number; ++i)
pthread_create (& nbthreads[i], NULL , f, &i);
for (int i=0; i < number; ++i)
pthread_join(nbthreads[i], NULL);
pthread_exit(NULL);

  return 0;
}
