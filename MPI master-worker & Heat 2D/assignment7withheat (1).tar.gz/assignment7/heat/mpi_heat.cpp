#include <mpi.h>
#include <math.h>
#include <iostream>
#include <chrono>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

  int check2DHeat(double** H, long n, long rank, long P, long k); //this assumes array of array and grid block decomposition

#ifdef __cplusplus
}
#endif

/***********************************************
 *         NOTES on check2DHeat.
 ***********************************************
 *         
 *  First of, I apologize its wonky. 
 *
 *  Email me ktibbett@uncc.edu with any issues/concerns with this. Dr. Saule or the other
 *    TA's are not familiar with how it works. 
 *
 * Params:
 *  n - is the same N from the command line, NOT the process's part of N
 *  P - the total amount of processes ie what MPI_Comm_size gives you.
 *  k - assumes n/2 > k-1 , otherwise may return false negatives.
 *
 *   
 * Disclaimer:
 ***
 *** Broken for P is 9. Gives false negatives, for me it was always
 ***  ranks 0, 3, 6. I have not found issues with 1, 4, or 16, and these
 ***  are what `make test` will use.
 ***
 *
 * Usage:
 *  When code is WRONG returns TRUE. Short example below
 *  if (check2DHeat(...)) {
 *    // oh no it is (maybe) wrong  
 *    std::cout<<"rank: "<<rank<<" is incorrect"<<std::endl;
 *  }
 *
 *
 *
 *  I suggest commenting this out when running the bench
 *
 *
 * - Kyle
 *
 *************/


// Use similarily as the genA, genx from matmult assignment.
double genH0(long row, long col, long n) {
  double val = (double)(col == (n/2));
  return val;
}


void heat(long block, double** H_of_Cur, double** H_of_Pre, double* recv_left, double* recv_right, double* recv_up, double* recv_down){
  int row, col;
  for (row = 0; row < block; ++row) { 
    for (col = 0; col < block; ++col) {
      if(row == 0){
	H_of_Cur[row][col] = (recv_up[col] + H_of_Pre[row][col-1] + H_of_Pre[row][col] + H_of_Pre[row][col+1] + H_of_Pre[row+1][col])/(static_cast<double>(5));
      }
      else if(row == block-1){
	H_of_Cur[row][col] = (recv_down[col] + H_of_Pre[row-1][col] + H_of_Pre[row][col-1] + H_of_Pre[row][col] + H_of_Pre[row][col+1])/(static_cast<double>(5));
      }
      else if(col == 0){
	H_of_Cur[row][col] = (recv_left[row] + H_of_Pre[row-1][col] + H_of_Pre[row][col] + H_of_Pre[row][col+1] + H_of_Pre[row+1][col])/(static_cast<double>(5));
      }
      else if(col == block-1){
	H_of_Cur[row][col] = (recv_right[row] + H_of_Pre[row-1][col] + H_of_Pre[row][col-1] + H_of_Pre[row][col]+ H_of_Pre[row+1][col])/(static_cast<double>(5));
      }
      else if(row == 0 && col == 0){
	H_of_Cur[row][col] = (recv_left[row] + recv_up[col] + H_of_Pre[row][col] + H_of_Pre[row][col+1] + H_of_Pre[row+1][col])/(static_cast<double>(5));
      }
      else if(row == block-1 && col == 0){
	H_of_Cur[row][col] = (recv_left[row] + recv_down[col] + H_of_Pre[row-1][col] + H_of_Pre[row][col] + H_of_Pre[row][col+1])/(static_cast<double>(5));
      }
      else if(row == 0 && col == block-1){
	H_of_Cur[row][col] = (recv_right[row] + recv_up[col] + H_of_Pre[row][col-1] + H_of_Pre[row][col] + H_of_Pre[row+1][col])/(static_cast<double>(5));
      }
      else if(row == block-1 && col == block-1){
	H_of_Cur[row][col] = (recv_right[row] + recv_down[col] + H_of_Pre[row-1][col] + H_of_Pre[row][col-1] + H_of_Pre[row][col])/(static_cast<double>(5));;
      }
      else{
	H_of_Cur[row][col] = (H_of_Pre[row-1][col] + H_of_Pre[row][col-1] + H_of_Pre[row][col] + H_of_Pre[row][col+1] + H_of_Pre[row+1][col])/(static_cast<double>(5));
      }
    }
  }
  
  for (row = 0; row < block; ++row) {
    for (col= 0; col < block; ++col) {
      H_of_Pre[row][col] = H_of_Cur[row][col];
    }
  }  
}

int main(int argc, char* argv[]) {
  std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();
  if (argc < 3) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <N> <K>"<<std::endl;
    return -1;
  }

  MPI_Init(&argc, &argv);
  
  // declare and init command line params
  long N, K;
  N = atol(argv[1]);
  K = atol(argv[2]);  
  int rank, size;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  //dividing the matrix into blocks
  long sqrt_size = sqrt(size);
  long block = N/sqrt_size;
  long row_rank = rank/sqrt_size;
  long col_rank = rank%sqrt_size;
  
 double** H_of_Pre = new double*[block];
 double** H_of_Cur = new double*[block];
  //allocating memory for blocks
 for(long i = 0;i < block; ++i){
    H_of_Pre[i]=(double*)malloc(block * sizeof(double));
    H_of_Cur[i]=(double*)malloc(block * sizeof(double));
  }

  //generating the values in the matrix
 for (long row = row_rank*block; row < (row_rank+1)*block; row++) {
   for (long col = col_rank*block; col < (col_rank+1)*block; col++) {
     H_of_Cur[(row-(row_rank*block))][(col-(col_rank*block))] = genH0(row, col, N);
     H_of_Pre[(row-(row_rank*block))][(col-(col_rank*block))] = H_of_Cur[(row-(row_rank*block))][(col-(col_rank*block))];
   }
 }

 MPI_Request* request;
 MPI_Status* status;
  
 double* send_left = new double[block];
 double* recv_left = new double[block];
 double* send_right = new double[block];
 double* recv_right = new double[block];
 double* recv_up = new double[block];
 double* recv_down = new double[block]; 

  MPI_Barrier(MPI_COMM_WORLD);
  
//starting the for loop for total number of iterations

  for(long iter = 1; iter <= K; ++iter){

    for(long i = 0;i<block;i++){
      recv_left[i]=H_of_Pre[i][0];
      recv_right[i]=H_of_Pre[i][(block-1)];
      recv_up[i]=H_of_Pre[0][i];
      recv_down[i]=H_of_Pre[(block-1)][i];
    }


//for one processor
if(size == 1){  
      
      heat(block, H_of_Cur, H_of_Pre, recv_left, recv_right, recv_up, recv_down);

      check2DHeat(H_of_Cur, block, rank, sqrt_size, iter);
      
    }
//for more then 1 processors
else{
      //if block=top left corner
      if(row_rank == 0 && col_rank == 0){
	
	for(long i = 0; i < block; i++){
	  send_right[i] = H_of_Pre[i][block-1];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(H_of_Pre[block-1], block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[3]);

	MPI_Waitall(4, request, status);
      }
      //if block=top right corner
      else if(row_rank == 0 && col_rank == (sqrt_size-1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_of_Pre[i][0];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(H_of_Pre[block-1], block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[3]);
	
	MPI_Waitall(4, request, status);
      }
      //if block=bottom left corner
      else if(row_rank == (sqrt_size-1) && col_rank == 0){
	
	for(long i = 0; i < block; i++){
	  send_right[i] = H_of_Pre[i][block-1];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(H_of_Pre[0], block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[3]);
	
	MPI_Waitall(4, request, status);
      }
      //if block=bottom right corner
      else if(row_rank == (sqrt_size - 1) && col_rank == (sqrt_size - 1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_of_Pre[i][0];
	}

	request = new MPI_Request[4];
	status = new MPI_Status[4];

	MPI_Isend(H_of_Pre[0], block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[3]);

	MPI_Waitall(4, request, status);
      }
      //for entire first row
      else if(row_rank == 0){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_of_Pre[i][0];
	  send_right[i] = H_of_Pre[i][block-1]; 
	}

	request = new MPI_Request[6];
	status = new MPI_Status[6];

	MPI_Isend(H_of_Pre[block-1], block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[5]);
	
	MPI_Waitall(6, request, status);
      }
      //for entire last row
      else if(row_rank == (sqrt_size-1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i] = H_of_Pre[i][0];
	  send_right[i] = H_of_Pre[i][block-1]; 
	}

	request = new MPI_Request[6];
	status = new MPI_Status[6];

	MPI_Isend(H_of_Pre[0], block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[5]);

	MPI_Waitall(6, request, status);
      }
      
      //for entire first column
      else if(col_rank == 0){

	for(long i = 0; i < block; i++){
	  send_right[i] = H_of_Pre[i][block-1]; 
	}

	request = new MPI_Request[6];
	status = new MPI_Status[6];
	
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Isend(H_of_Pre[block-1], block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Isend(H_of_Pre[0], block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request[5]);
	MPI_Waitall(6, request, status);
      }
	//for entire last column
      else if(col_rank == (sqrt_size-1)){
	
	for(long i = 0; i < block; i++){
	  send_left[i]=H_of_Pre[i][0];
	}
	
	request = new MPI_Request[6];
	status = new MPI_Status[6];

	MPI_Isend(H_of_Pre[0], block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[0]);
	MPI_Isend(H_of_Pre[block-1], block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[1]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[2]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request[3]);
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request[4]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request[5]);
	
	MPI_Waitall(6, request, status);
      }
      //for all the central elements
      else{
	
	for(long i = 0; i < block; i++){
	  send_left[i]=H_of_Pre[i][0];
	  send_right[i]=H_of_Pre[i][block-1];
	}

	MPI_Request* request_r;
	MPI_Request* request_s;
	request_r = new MPI_Request[4];
	request_s = new MPI_Request[4];
	status = new MPI_Status[4];
	
	MPI_Irecv(recv_up, block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request_r[0]);
	MPI_Irecv(recv_down, block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request_r[1]);
	MPI_Irecv(recv_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request_r[2]);
	MPI_Irecv(recv_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request_r[3]);
	MPI_Isend(H_of_Pre[0], block, MPI_DOUBLE, rank-sqrt_size, 0, MPI_COMM_WORLD, &request_s[0]);
	MPI_Isend(H_of_Pre[block-1], block, MPI_DOUBLE, rank+sqrt_size, 0, MPI_COMM_WORLD, &request_s[1]);
	MPI_Isend(send_left, block, MPI_DOUBLE, rank-1, 0, MPI_COMM_WORLD, &request_s[2]);
	MPI_Isend(send_right, block, MPI_DOUBLE, rank+1, 0, MPI_COMM_WORLD, &request_s[3]);
	MPI_Waitall(4, request_r, status);
      }
      //calculation of heat and checking the values
      heat(block, H_of_Cur, H_of_Pre, recv_left, recv_right, recv_up, recv_down);
      check2DHeat(H_of_Cur, block, rank, sqrt_size, iter);
      
    }
}

  //printing the time
  if(rank == 0){ 
  std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
  std::chrono::duration<double> elapsed_seconds = end-start;
  std::cerr<<elapsed_seconds.count()<<std::endl;
  }
  MPI_Finalize();
  for(long i = 0; i< block; i++){
    delete H_of_Pre[i];
    delete H_of_Cur[i];
  }
  delete[] H_of_Cur;
  delete[] H_of_Pre;
  delete[] send_left;
  delete[] recv_left;
  delete[] send_right;
  delete[] recv_right;
  delete[] recv_up;
  delete[] recv_down;
  
  return 0;
}

