#include <mpi.h>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
int main (int argc, char* argv[]) {

  if (argc < 2) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <value>"<<std::endl;
    return -1;
  }

int rank,size,data;
MPI_Init(&argc, &argv);
MPI_Comm_rank (MPI_COMM_WORLD, &rank);
if (rank == 0){
data=atoi(argv[1]);
MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
MPI_Recv(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
printf("%d",data);
}
else if (rank == 1){
MPI_Recv(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
data+=2;
MPI_Send(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
}
MPI_Finalize();
return 0;
}
