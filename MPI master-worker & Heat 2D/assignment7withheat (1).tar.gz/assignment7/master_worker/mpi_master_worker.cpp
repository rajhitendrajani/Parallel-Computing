#include <iostream>
#include <mpi.h>
#include <chrono>
using namespace std;
#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif


int main(int argc, char * argv[]) {

  if (argc < 6) {
    std::cerr << "usage: mpirun " << argv[0] << " <functionid> <a> <b> <n> <intensity>" << std::endl;
    return -1;
  }

  //Timer Start
  std::chrono::time_point < std::chrono::system_clock > start = std::chrono::system_clock::now();

  int functionid = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  int rank,size;
  int first = 0, last = 0;
  int end_process = -1;
  double x,integral;

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Status status;
  int count = size;
  int gran = (n/size)/8;
    
    if(rank == 0){
    
      for(int i = 1; i < size; ++i){
	int j = i;
	if(n >= first + gran){
	  MPI_Send(&first, 1, MPI_INT, i, j, MPI_COMM_WORLD);
	  first += gran;
	}
	else{
	  if(count == size){
	    MPI_Send(&first, 1, MPI_INT, i, j, MPI_COMM_WORLD);
	    count--;
	  }
	  else{
	    count--;
	    MPI_Send(&end_process, 1, MPI_INT, i, j, MPI_COMM_WORLD);
	  }
	}
      }
      
      while(count != 1){
	double sum = 0.0;
	MPI_Recv(&sum, 1, MPI_DOUBLE, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
	integral += sum;
	
	if(first < n){
	  MPI_Send(&first, 1, MPI_INT, status.MPI_SOURCE, rank, MPI_COMM_WORLD);
	  first += gran;
	}
	else{
	  count--;
	  MPI_Send(&end_process, 1, MPI_INT, status.MPI_SOURCE, rank, MPI_COMM_WORLD);
	}
      }
      
      integral = integral * ((float)(b-a)/n);
    }
    

    else{
    
      while(1){
	
	double sum = 0.0;
	MPI_Recv(&first, 1, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
	if(first == -1)
	break;
	last = first + gran;
	if(last > n)
	  last = n;
	
	for(int i = first; i < last; ++i){
	  x = (a + (i + 0.5) * ((float)(b-a)/n));
	  switch(functionid){
	  case 1:
	    sum += f1(x, intensity);
	    break;
	  case 2:
	    sum += f2(x, intensity);
	    break;
	  case 3:
	    sum += f3(x, intensity);
	    break;
	  case 4:
	    sum += f4(x, intensity); 
	    break;
	  default: exit;
	  }
	}
	MPI_Send(&sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
      }
    }

  if(rank == 0){
    std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    std::cout << integral << std::endl;
    std::cerr << elapsed_seconds.count() << std::endl;
  }
 //Terminates MPI execution environment
  MPI_Finalize();
  return 0;

}
