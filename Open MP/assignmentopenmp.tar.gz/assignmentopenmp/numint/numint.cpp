#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif
float sub,k,t,x;
int i;

int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 9) {
    std::cerr<<"Usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }
		
		int fid = atoi(argv[1]);
		int  a = atoi(argv[2]);
	 	int b = atoi(argv[3]);
		int n = atoi(argv[4]);
 		int intensity = atoi(argv[5]);
  		int nbthreads = atoi(argv[6]);
  		char* sched = argv[7];
  		int gran = atoi(argv[8]);
  		sub = b-a;
		t = sub/n;
		if(strcmp(sched , "static") == 0){ 
		omp_set_schedule(omp_sched_static,gran);
} 
		if(strcmp(sched , "dynamic") == 0){ 
		omp_set_schedule(omp_sched_dynamic,gran);
} 
auto start = std::chrono::high_resolution_clock::now();
	#pragma omp parallel for reduction(+:k)		
		for(i=0;i<n;i++){	
				x = a +( (i + .5 ) * t);			
				switch(fid){
					case 1:
						k=k+f1( x, intensity);
					break;
					case 2:
						k=k+f2( x, intensity);
					break;
					case 3:
						k=k+f3( x, intensity);
					break;
					case 4:
						k=k+f4( x, intensity);
					break;
					default: printf("Wrong fid");
					}
				}
		k=k*t;
auto finish = std::chrono::high_resolution_clock::now();
std::chrono::duration<double> elapsed = finish - start;
		std::cout<<k<<std::endl;
		std::cerr<<elapsed.count()<<std::endl;
  return 0;
}
