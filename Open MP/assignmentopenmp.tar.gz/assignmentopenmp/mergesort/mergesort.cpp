#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <omp.h>
#include <algorithm> 
#include <math.h> 
#include <cstdint> 
#include <cstring> 
#include <chrono>
using namespace std;
#ifdef __cplusplus
extern "C" {
#endif
  void generateMergeSortData (int* arr, size_t n);
  void checkMergeSortResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif
void mergeSort(int arr[], int merge[] , int n, int start, int mid, int end)
{
  int start_l = start;
  int start_r = start;
  int current = mid+1;
  
  while(start_l <= mid && current <= end){
    if(arr[start_l] < arr[current])
      merge[start_r++] = arr[start_l++];
    else
      merge[start_r++] = arr[current++];
  }
  while(start_l <= mid){
    merge[start_r++] = arr[start_l++];
  } 
  for(int i = start; i <= end; i++){
    arr[i] = merge[i];
  }
}

int main (int argc, char* argv[]) {

  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 3) { std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
  int * arr = new int [n];
  
  generateMergeSortData (arr, n);

  omp_set_num_threads(nbthreads);
int *merge=(int*)malloc(n * sizeof(int));
std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();
  //copy array into new array
  for(int i = 0; i < n; i++){
    merge[i] = arr[i];
  }
  for (int i=1; i<n; i=2*i)
  {
#pragma omp parallel for schedule(static)
    for (int start = 0; start < n-1; start=start+(2*i))
    {
      int mid = min(start+i-1, n-1);
      int end = min(start+(2*i)-1, n-1);
      
      int start_l = start;
      int start_r = start;
      int current = mid+1;
      
      while(start_l <= mid && current <= end){
        if(arr[start_l] < arr[current])
          merge[start_r++] = arr[start_l++];
        else
          merge[start_r++] = arr[current++];
      }
      while(start_l <= mid){
        merge[start_r++] = arr[start_l++];
      }
      for(int i = start; i <= end; i++){
        arr[i] = merge[i];
      }
    }
  }
std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
std::chrono::duration<double> elapsed_seconds = end-start;
std::cerr<<elapsed_seconds.count()<<std::endl;
  checkMergeSortResult (arr, n);
  
  delete[] arr;

  return 0;
}
