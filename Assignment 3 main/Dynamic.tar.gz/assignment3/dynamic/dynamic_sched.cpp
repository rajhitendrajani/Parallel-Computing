#include <iostream>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

int n;
int current=0;
pthread_mutex_t mut;
pthread_mutex_t mut2;

struct th_info {
	
	int th_id;
	float a;
	float b;
	int n;
	int intensity;
	int fun_id;
	int gran;
	float* res;
	int sync;
};

void getnext(int* begin , int* end,int gran)
{
        *begin = ::current;
        if((::current + gran) >= ::n) *end = n - 1;
        else *end = ::current + gran - 1;
        ::current += gran;
        pthread_mutex_unlock(&mut2);
}

bool done()
{
        pthread_mutex_lock(&mut2);
        if(::current >= ::n){
                pthread_mutex_unlock(&mut2);
                return true;
         }
        else return false;
}

float execute_inner_loop(int begin , int end , int fun_id, float a ,float b,int intensity,int sync,float* res_t)
{
        int i; float temp_res=0;
        if(sync == 1)
        {
                switch(fun_id)
                {
                        case 1:
                        for(i=begin;i<=end;i++)
                        {
                          pthread_mutex_lock(&mut);
                          *res_t = *res_t + f1((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                          pthread_mutex_unlock(&mut);
                        }
                        break;
                        case 2:
                        for(i=begin;i<=end;i++)
                        {
                          pthread_mutex_lock(&mut);
                          *res_t= *res_t + f2((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                          pthread_mutex_unlock(&mut);
                        }
                        break;
                        case 3:
                        for(i=begin;i<=end;i++)
                        {
                          pthread_mutex_lock(&mut);             
                          *res_t = *res_t + f3((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                          pthread_mutex_unlock(&mut);
                        }
                        break;
                        case 4:
                        for(i=begin;i<=end;i++)
                        {
                          pthread_mutex_lock(&mut);
                          *res_t = *res_t + f4((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                          pthread_mutex_unlock(&mut);           
                        }
                        break;
                }
                return temp_res;
        }
        
        if(sync == 2)
        {
                switch(fun_id)
                {
                        case 1:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f1((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                        case 2:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f2((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                        case 3:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f3((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                        case 4:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f4((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                }
                
                pthread_mutex_lock(&mut);
                *res_t += temp_res;
                pthread_mutex_unlock(&mut);
                return temp_res;
        }
        
        if(sync == 3)
        {
                switch(fun_id)
                {
                        case 1:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f1((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                        case 2:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f2((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                        case 3:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f3((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                        case 4:
                        for(i=begin;i<=end;i++)
                        {
                          temp_res = temp_res + f4((a+ (i+0.5)*((b-a)/n)),intensity)*((b-a)/n);
                        }
                        break;
                }
        
        return temp_res;
                
        }
}

void* thread_func(void* p)
{
        struct th_info* q = (struct th_info*)p;
         float res_par = 0;int i,begin,end;float temp=0;
        while(!done())
        {
                getnext(&begin,&end,q->gran);
                if(q->sync == 3)
                { 
                temp=execute_inner_loop(begin,end,q->fun_id,q->a,q->b,q->intensity,q->sync,q->res);
                        res_par+=temp;
                }
                else execute_inner_loop(begin,end,q->fun_id,q->a,q->b,q->intensity,q->sync,q->res);
        }
        
        if(q->sync == 3)
        {
                pthread_mutex_lock(&mut);
                *(q->res) += res_par;
                pthread_mutex_unlock(&mut);
        }       
}



int main (int argc, char* argv[]){

  if (argc < 9) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync> <granularity>"<<std::endl;
    return -1;
  }

float a=0;
float b=0;
float result=0;
int n,intensity,fid,number,i,gran,temp_sync;

	sscanf(argv[3], "%f",&b);
	sscanf(argv[2], "%f",&a);
	sscanf(argv[4], "%d",&n);
	sscanf(argv[5], "%d",&intensity);
	sscanf(argv[1], "%d",&fid);
	sscanf(argv[6], "%d",&number);
	sscanf(argv[8], "%d",&gran);
	char* sync=argv[7];
  	::n = n;
  	if(strcmp(sync,"iteration") == 0)
  	{
        	temp_sync = 1;
  	}
  	if(strcmp(sync,"chunk") == 0) 
  	{
        	temp_sync = 2;
  	}
  	if(strcmp(sync,"thread") == 0)
  	{ 
    	temp_sync = 3;
  	}

pthread_t *thread = (pthread_t*)malloc(number * sizeof(pthread_t));
struct th_info *temp=(struct th_info*)malloc(number * sizeof(th_info));

for(i = 0;i<number;i++)
        {
                temp[i].th_id = i;
                temp[i].fun_id = fid;
                temp[i].a = a;
                temp[i].b = b;
                temp[i].n = n;          
                temp[i].intensity = intensity;
                temp[i].gran = gran;            
                temp[i].res = &result;
                temp[i].sync = temp_sync;
        }

std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();

        for(i = 0;i<number;i++)
                {
                        pthread_create(&thread[i] , NULL , thread_func , &temp[i]);
                }
                
        for(i = 0;i<number;i++)
                {
                        pthread_join(thread[i] , NULL);
                }
        
        std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end-start;


        std::cout<<result<<std::endl;
        std::cerr<<elapsed_seconds.count()<<std::endl;

  return 0;
}

