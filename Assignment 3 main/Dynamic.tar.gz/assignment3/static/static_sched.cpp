#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include <cmath>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif
struct th_info {
	
	
	float a;
	float b;
	int n;
	int intensity;
	int fun_id;
	int begin;
	int ending;
	int tid;
	float* res;
};
pthread_mutex_t mut;

void* thread1(void* p)
{
	struct th_info* q = (struct th_info*)p;
	float res_par = 0;int i;float temp;
	switch(q->fun_id)
	{
	  case 1:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  res_par = res_par + f1((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
	  }
	  break;
	  case 2:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  res_par = res_par + f2((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
	  }  
	  break;	  
	  case 3:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  res_par = res_par + f3((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
	  }  
	  break;
	  case 4:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  res_par = res_par + f4((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
	  }
	  break;
	  
	}	
	pthread_mutex_lock(&mut);
	*q->res += res_par;
	pthread_mutex_unlock(&mut);
	
	return NULL;

}

void* iterate2(void* p)
{
	struct th_info* q = (struct th_info*)p;
	int i;float temp;float temp2;
	switch(q->fun_id)
	{
	  case 1:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  temp2 = f1((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
		  pthread_mutex_lock(&mut);
		  *q->res = *q->res + temp2;
		  pthread_mutex_unlock(&mut);
	  }
	  break;
	  case 2:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  temp2 = f2((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
		  pthread_mutex_lock(&mut);
		  *q->res = *q->res + temp2; 
		  pthread_mutex_unlock(&mut);
	  }  
	  break;	  
	  case 3:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  temp2 = f3((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
		  pthread_mutex_lock(&mut);
		  *q->res = *q->res + temp2;
		  pthread_mutex_unlock(&mut);
	  }  
	  break;
	  case 4:
	  for(i = q->begin;i<=q->ending;i++)
	  {
		  temp2 = f4((q->a+ (i+0.5)*((q->b-q->a)/q->n)),q->intensity)*((q->b-q->a)/q->n);
		  pthread_mutex_lock(&mut);
		  *q->res = *q->res + temp2; 
		  pthread_mutex_unlock(&mut);
	  }
	  break;
	  
	}	
}


int main (int argc, char* argv[]) {

  if (argc < 8) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync>"<<std::endl;
    return -1;
  }
float a=0;
float b=0;
float result=0;
int n,intensity,fid,number,i;

	sscanf(argv[3], "%f",&b);
	sscanf(argv[2], "%f",&a);
	sscanf(argv[4], "%d",&n);
	sscanf(argv[5], "%d",&intensity);
	sscanf(argv[1], "%d",&fid);
	sscanf(argv[6], "%d",&number);
	char* sync=argv[7];
	
pthread_t *thread = (pthread_t*)malloc(number * sizeof(pthread_t));
struct th_info *temp=(struct th_info*)malloc(number * sizeof(th_info));
  	int slots = n/number;
for(i = 0;i<number;i++)
	{
		temp[i].tid = i;
		temp[i].fun_id = fid;
		temp[i].a = a;
		temp[i].b = b;
		temp[i].n = n;		
		temp[i].begin = i*slots;
		if(i==number-1){
				 temp[i].ending=n-1;
				}

		else{
			temp[i].ending=((i+1)*slots)-1;
			}
		temp[i].intensity=intensity;		
		temp[i].res=&result;
	}
std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();

	if(strcmp(sync,"thread")==0)
	{
		for(i=0;i<number;i++)
		{
			pthread_create(&thread[i] , NULL , thread1 , &temp[i]);
		}
	}
	
	if(strcmp(sync,"iteration")==0)
	{
		for(i=0;i<number;i++)
		{
			pthread_create(&thread[i] , NULL , iterate2 , &temp[i]);
		}
		
	}

	for(i = 0;i<number;i++)
	{
			pthread_join(thread[i] , NULL);
	}
	
	std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds = end-start;

	std::cout<<result<<std::endl;
	std::cerr<<elapsed_seconds.count()<<std::endl;
  
  return 0;
}
